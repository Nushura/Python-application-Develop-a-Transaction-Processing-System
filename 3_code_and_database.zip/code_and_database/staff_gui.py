# Staff user interface

# Importing packages
import tkinter as tk
from tkinter import messagebox
import tkinter.ttk as tkk

# Importing classes defined in other files thats needed in this class
from staff_dao import StaffDAO
from validation import Validation


class StaffGUI():
    """GUI class to perform CRUD operations on the staff table in the database"""

    def __init__(self):
        """Initialiser"""

        # Connecting to database which is the staff_dao.py file
        self.staff_dao = StaffDAO()

        # Form fields
        self.staff_id = tk.StringVar()
        self.title = tk.StringVar()
        self.first_name = tk.StringVar()
        self.last_name = tk.StringVar()
        self.phone = tk.StringVar()
        self.email = tk.StringVar()

        # List of staff ids
        # lb is indicating to list-box
        self.lb_ids = None

        # Message box title
        self.message_box_title = "Staff CRUD"

        # Instantiating validation object which contains methods to validate input fields
        self.validator = Validation()

        pass

    def create_gui(self, root):
        """ It is acting as a container which will hold the full GUI """
        print("\nCreating staff GUI ....\n")

        staff_frame = tk.Frame(root)
        staff_frame.pack()  # Pack method will center everthing inside

        form_frame = tk.Frame(staff_frame)
        form_frame.pack()

        # Making the title of the form and spreading it across 3 columns
        # --------------------------------------------------------------
        # Row 0
        # --------------------------------------------------------------

        # Window heading
        tk.Label(
            form_frame,
            font=('arial', 16),
            text="STAFF",
            padx=2,
            pady=10).grid(row=0, column=0, columnspan=3)

        # --------------------------------------------------------------
        # Row 1
        # --------------------------------------------------------------

        # For headings
        tk.Label(
            form_frame,
            font=('arial', 16),
            text="Staff IDs",
            padx=2,
            pady=20).grid(row=1, column=0, columnspan=1)

        tk.Label(
            form_frame,
            font=('arial', 16),
            text="Details",
            padx=2,
            pady=20).grid(row=1, column=1, columnspan=2)

        # --------------------------------------------------------------
        # Row 2
        # --------------------------------------------------------------

        # Form fields starts here

        # Row 2 -- Creating a frame isnide form_frame for list box that will contain the ids
        self.lb_ids = tk.Listbox(form_frame)
        self.lb_ids.grid(row=2, column=0, rowspan=6)

        #  Setting the method to be called when an item is clicked on the listbox
        self.lb_ids.bind('<<ListboxSelect>>', self.on_list_select)

        # Row 2 label field
        tk.Label(
            form_frame,
            font=('arial', 12),
            text="Staff ID",
            width=20,
            # anchor="e",
            # bd=1,
            pady=5,
            padx=5).grid(row=2, column=1)

        # Row 2 entry field
        tk.Entry(
            form_frame,
            textvariable=self.staff_id,
            width=30,
            # bd = 1,
            state=tk.DISABLED).grid(row=2, column=2)

        # --------------------------------------------------------------
        # Row 3
        # --------------------------------------------------------------

        # Row 3 label field
        tk.Label(
            form_frame,
            font=('arial', 12),
            text="Title",
            width=20,
            # anchor="e",
            # bd=1,
            pady=5,
            padx=5).grid(row=3, column=1)

        # Row 3 entry field
        tk.Entry(
            form_frame,
            textvariable=self.title,
            width=30).grid(row=3, column=2)

        #  --------------------------------------------------------------
        # Row 4
        # --------------------------------------------------------------

        # Row 4 label field
        tk.Label(
            form_frame,
            font=('arial', 12),
            text="First Name",
            width=20,
            # anchor="e",
            # bd=1,
            pady=5,
            padx=5).grid(row=4, column=1)

        # Row 4 entry field
        tk.Entry(
            form_frame,
            textvariable=self.first_name,
            width=30).grid(row=4, column=2)

        #  --------------------------------------------------------------
        # Row 5
        # --------------------------------------------------------------

        # Row 5 label field
        tk.Label(
            form_frame,
            font=('arial', 12),
            text="Last Name",
            width=20,
            # anchor="e",
            # bd=1,
            pady=5,
            padx=5).grid(row=5, column=1)

        # Row 5 entry field
        tk.Entry(
            form_frame,
            textvariable=self.last_name,
            width=30).grid(row=5, column=2)

        #  --------------------------------------------------------------
        # Row 6
        # --------------------------------------------------------------

        # Row 6 label field
        tk.Label(
            form_frame,
            font=('arial', 12),
            text="Phone no.",
            width=20,
            # anchor="e",
            # bd=1,
            pady=5,
            padx=5).grid(row=6, column=1)

        # Row 6 entry field
        tk.Entry(
            form_frame,
            textvariable=self.phone,
            width=30).grid(row=6, column=2)

        #  --------------------------------------------------------------
        # Row 7
        # --------------------------------------------------------------

        # Row 7 label field
        tk.Label(
            form_frame,
            font=('arial', 12),
            text="Email",
            width=20,
            # anchor="e",
            # bd=1,
            pady=5,
            padx=5).grid(row=7, column=1)

        # Row 7 entry field
        tk.Entry(
            form_frame,
            textvariable=self.email,
            width=30).grid(row=7, column=2)

        # Creating a new frame for buttons inside the staff_frame
        button_frame = tk.Frame(staff_frame)
        button_frame.pack()

        tk.Button(
            button_frame,
            width=10,
            text="CLEAR",
            pady=5,
            padx=5,
            command=self.clear_all_fields).pack(side=tk.RIGHT)

        tk.Button(
            button_frame,
            width=10,
            text="SAVE",
            pady=5,
            padx=5,
            command=self.save_record).pack(side=tk.RIGHT)

        tk.Button(
            button_frame,
            width=10,
            text="DELETE",
            pady=5,
            padx=5,
            command=self.delete).pack(side=tk.RIGHT)

        tk.Button(
            button_frame,
            width=10,
            text="LOAD",
            pady=5,
            padx=5,
            command=self.load).pack(side=tk.RIGHT)

        # Return a reference to the high level frame created
        # Will need the reference to be able to destroy it in the calling function
        return staff_frame

    def clear_all_fields(self):
        """ This will help to clear all the fields inside the form in one click """
        print("\nClearing fields ...")

        self.staff_id.set("")
        self.title.set("")
        self.first_name.set("")
        self.last_name.set("")
        self.phone.set("")
        self.email.set("")

    def save_record(self):
        """ Save the data within the form """
        print("\nSaving a staff record....")

        # Retrieving the data
        data = self.get_fields()

        # Validating data
        valid_data, message = self.validate_fields(data)

        # If data entered is valid data the the if condition checkes for existing staff in the system
        # and if present then their record is udated
        # or else a new staff record is added to the system
        if valid_data:
            if (len(data['staff_id']) == 0):
                print(
                    "Calling create() method as the staff is not present in the databse")
                self.create(data)
            else:
                print(
                    "Calling update() method as the staff is already recorded in the database")
                self.update(data)
                pass
        # However, if invalid data is entered then error message will be shown
        else:
            message_text = "Invalid fields. \n" + message
            messagebox.showwarning(
                self.message_box_title, message_text, icon="warning")
            pass

    def get_fields(self):
        """ This will assist to get the data entered in the form fields """
        print("\nGetting fields ...")

        staff = {}

        staff['staff_id'] = self.staff_id.get()
        staff['title'] = self.title.get()
        staff['first_name'] = self.first_name.get()
        staff['last_name'] = self.last_name.get()
        staff['phone'] = self.phone.get()
        staff['email'] = self.email.get()

        print(f"staff: {staff}")
        return staff

    def create(self, data):
        """ This will help when creating/entering new record in the database """

        print("\nCreating a staff record ...")

        print(f"data: {data}")

        result = self.staff_dao.create(data)

    def update(self, data):
        """ This will assist in updating a record in the database """

        print("\nUpdating a staff record ...")

        print(f"data: {data}")

        result = self.staff_dao.update(data['staff_id'], data)

        # Display the returned message to the user using a messagebox
        # Display everything that is retrned in the result
        messagebox.showinfo(self.message_box_title, result)

    def delete(self):
        """ This will help to delete a record from the databse """

        print("\nDeleting the staff\n")

        # Grab the staff_id from the stringvar
        id = self.staff_id.get()
        print(f"id: {id}")

        # Call the data access object to do the job
        # Pass the id as parameter to the delete() method
        result = self.staff_dao.delete(id)

        # Display the returned message to the user - use a messagebox
        # Display everything that is returned in the result
        messagebox.showinfo(self.message_box_title, result)
        pass

    def load(self):
        """Retrieve a list of IDs from the database and load them into a listbox"""

        print("\nLoading IDs in list box...")

        result = self.staff_dao.find_ids()
        print(f"result: {result}")

        # Checcking if there is an entry in the result dictionary
        if "staff_ids" in result:
            # It will crash if there is no entry!
            list_ids = result['staff_ids']

            # Setting the returned list into the listbox in our UI
            # Before doing that, must clear any previous list in the box
            self.lb_ids.delete(0, tk.END)
            print("Setting staff_ids in the listbox...")
            for x in list_ids:
                self.lb_ids.insert(tk.END, x)

        pass

    def on_list_select(self, evt):
        """ This method is triggered when someone clicks an item from the listbox """
        print("\nSelecting an item from the list box.")

        w = evt.widget

        # Index refers to the list item that has been selected
        index = int(w.curselection()[0])

        # Record of the item that has been clicked on, in our case that is the staff id
        record = w.get(index)

        print(f"index: {index}")
        print(f"record: {record}")

        # Call find_by_id and populate the stringvars of the form
        result = self.staff_dao.find_by_id(record)

        print(f"result: {result}")

        # Taking the staff dict from result dict and
        # using it to populate the fields on the form
        staff = result['staff']
        self.populate_fields(staff)

    def populate_fields(self, staff):
        """ This will create/poplate the fields of the form with data """

        print("\nPopulating the fields.\n")
        print(f"staff: {staff}")

        # Set the values from the dict to the stringvars
        self.staff_id.set(staff['staff_id'])
        self.title.set(staff['title'])
        self.first_name.set(staff['first_name'])
        self.last_name.set(staff['last_name'])
        self.phone.set(staff['phone'])
        self.email.set(staff['email'])

    def validate_fields(self, data):
        # This method will help to validate data entered in the form fields

        print("\nValidating the data.....\n")
        print(f"data: {data}")

        # Initially by default the value of valid_data is set to true,
        valid_data = True
        # Instantiate an empty list to contain the messages
        message_list = []

        # Checking for blank fields
        if len(data['title']) == 0:
            valid_data = False
            message_list.append("Title field is empty")
        if len(data['first_name']) == 0:
            valid_data = False
            message_list.append("First name field is empty")
        if len(data['last_name']) == 0:
            valid_data = False
            message_list.append("Last name field is empty")
        if len(data['phone']) == 0:
            valid_data = False
            message_list.append("Phone field is empty")
        if len(data['email']) == 0:
            valid_data = False
            message_list.append("Email field is empty")

        # Other possible checks

        # These functions are implemented in the Validation class so that
        # other classes can call them.

        # Checking if title, first_name and last_name contain
        # only alphabetic characters
        if not self.validator.is_alphabetic(data['title']):
            valid_data = False
            message_list.append("Invalid title")

        if not self.validator.is_alphabetic(data['first_name']):
            valid_data = False
            message_list.append("Invalid first name")

        if not self.validator.is_alphabetic(data['last_name']):
            valid_data = False
            message_list.append("Invalid last name")

        # Checking if work_phone follows a certain pattern
        if not self.validator.is_phone_number(data['phone']):
            valid_data = False
            message_list.append("invalid phone number format")

        # Checking if email follows a certain pattern
        # i.e contains an @ followed by a dot
        if not self.validator.is_email(data['email']):
            valid_data = False
            message_list.append("Invalid email format")

        # Joining the items in the list as a string separated with a comma and a space
        message = ', '.join(message_list)

        return valid_data, message  # return 2 values
        pass


# Main method
if __name__ == '__main__':

    # Setting up a root window
    root = tk.Tk()
    root.title("EFL LIBRARY SYSTEM")
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    width = 1000
    height = 600
    x = (screen_width/2) - (width/2)
    y = (screen_height/2) - (height/2)
    root.geometry('%dx%d+%d+%d' % (width, height, x, y))
    root.resizable(0, 0)

    # Instantiating the staff GUI
    gui = StaffGUI()

    # Creating the GUI and passing the root window as a parameter
    gui.create_gui(root)

    # Running the main loop
    root.mainloop()

    pass
