# Creating tables acccording to the ERD for library system

# Importing necessary libraries
import sqlite3

DATABASE_URI = "EFL_library_system.db"

# Creating staff table
STAFF_SQL = """
    CREATE TABLE staff (
        staff_id    INTEGER PRIMARY KEY AUTOINCREMENT,
        title       VARCHAR(10) NOT NULL,
        first_name  VARCHAR(20) NOT NULL,
        last_name   VARCHAR(50) NOT NULL,
        phone       VARCHAR(20) NOT NULL UNIQUE,
        email       VARCHAR(50) NOT NULL UNIQUE
    )
"""
# Creating library user table
LIBRARY_USER_SQL = """
    CREATE TABLE library_user (
        user_id     INTEGER PRIMARY KEY AUTOINCREMENT,
        staff_id    INTEGER NOT NULL,
        title       VARCHAR(10) NOT NULL,
        first_name  VARCHAR(20) NOT NULL,
        last_name   VARCHAR(50) NOT NULL,
        age         VARCHAR(03) NOT NULL,
        phone       VARCHAR(20) NOT NULL UNIQUE,
        email       VARCHAR(50) NOT NULL UNIQUE,
        CONSTRAINT fk_staff
            FOREIGN KEY (staff_id)
            REFERENCES staff(staff_id)
)
"""

# Creating book table
BOOK_SQL = """
    CREATE TABLE book (
        book_id             INTEGER PRIMARY KEY AUTOINCREMENT,
        staff_id            INTEGER NOT NULL,
        title               VARCHAR(50) NOT NULL,
        author_firstname    VARCHAR(20) NOT NULL,
        author_lastname     VARCHAR(50) NOT NULL,
        genre               VARCHAR(50) NOT NULL,
        donator_firstname   VARCHAR(20) NOT NULL,
        donator_lastname    VARCHAR(50) NOT NULL,
        donation_date       VARCHAR(10) NOT NULL,
        CONSTRAINT fk_staff
            FOREIGN KEY (staff_id)
            REFERENCES staff(staff_id)
)
"""
# Creating loan table
LOAN_SQL = """
    CREATE TABLE loan (
        borrow_id         INTEGER PRIMARY KEY AUTOINCREMENT,
        book_id           INTEGER NOT NULL,
        user_id           INTEGER NOT NULL,
        borrow_date       VARCHAR(10) NOT NULL,
        return_date       VARCHAR(10) NOT NULL,
        CONSTRAINT fk_book
            FOREIGN KEY (book_id)
            REFERENCES book(book_id),

        CONSTRAINT fk_user
            FOREIGN KEY (user_id)
            REFERENCES library_user(user_id)
)
"""

# The reference for how to add the foreign keys is taken from this link:
# https://www.techonthenet.com/sqlite/foreign_keys/foreign_keys.php#:~:text=How%20to%20Add%20a%20Foreign,data%20into%20the%20new%20table.


# Main method
if __name__ == '__main__':

    print("Creating the database and tables")
    print()
    input("Press 'Enter' to continue or 'Ctrl'+'C' to cancel.")

    # Opening a connection
    conn = sqlite3.connect(DATABASE_URI)
    conn.execute("PRAGMA foreign_keys = 1")
    cur = conn.cursor()
    print(f"Connection maed to database {DATABASE_URI}")

    with conn:
        # Geting a cursor
        # Cur is refering to the conn opened connection and
        # then using the cursor(), in-built method, to access a cursor into the database
        cur = conn.cursor()
        print("Got a cursor to the connection")

        # Creating the staff table
        cur.execute(STAFF_SQL)
        print(f"Staff table created in database {DATABASE_URI}")

        # Creating the library user table
        cur.execute(LIBRARY_USER_SQL)
        print(f"Library user table created in database {DATABASE_URI}")

        # Creating the book table
        cur.execute(BOOK_SQL)
        print(f"Book table created in database {DATABASE_URI}")

        # Creating the loan table
        cur.execute(LOAN_SQL)
        print(f"Loan table created in database {DATABASE_URI}")

    print("\nAll tables successfully created!")

    print("\nPlease use DB Browser for SQLite to check the database!")
