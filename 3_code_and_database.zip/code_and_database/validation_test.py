# Import file/class to test
from validation import Validation

# Testing the is_numeric class from Validation class


def test_is_numeric(validation):
    print("\n1.Testing is_numeric()")

    # True
    assert (validation.is_numeric(10))

    # False
    assert (not validation.is_numeric(10.002))
    assert (not validation.is_numeric("abc"))
    assert (not validation.is_numeric("10abc"))

# Testing the is_alphabetic class from Validation class


def test_is_alphabetic(validation):
    print("\n2. Testing is_alphabetic()")

    # True
    assert (validation.is_alphabetic("abc"))

    # False
    assert (not validation.is_alphabetic(10))
    assert (not validation.is_alphabetic(10.002))
    assert (not validation.is_alphabetic("10abc"))

# Testing the is_alphanumeric class from Validation class


def test_is_alphanumeric(validation):
    print("\n3. Testing is_alphanumeric()")

    # True
    assert (validation.is_alphanumeric(10))
    assert (validation.is_alphanumeric("abc"))
    assert (validation.is_alphanumeric("10abc"))

    # False
    assert (not validation.is_alphanumeric(10.02))
    assert (not validation.is_alphanumeric("_"))
    assert (not validation.is_alphanumeric(" "))
    assert (not validation.is_alphanumeric("."))

# Testing the is_phone_number class from Validation class


def test_is_phone_number(validation):
    print("\n4. Testing is_phone_number()")

    # True
    assert (validation.is_phone_number("0414570776"))
    assert (validation.is_phone_number("04 1457 0776"))
    assert (validation.is_phone_number("61411543655"))
    assert (validation.is_phone_number("61 411 543 655"))
    assert (validation.is_phone_number("+61411543655"))
    assert (validation.is_phone_number("+61 411 543 655"))

    # False
    assert (not validation.is_phone_number("(04) 14570776"))
    assert (not validation.is_phone_number("04 145 707 76"))
    assert (not validation.is_phone_number("61-4115-4365"))
    assert (not validation.is_phone_number("614 1154 3655"))
    assert (not validation.is_phone_number("+61 2 1154 9999"))
    assert (not validation.is_phone_number("0413 888 888"))


# Testing the is_email class from Validation class
def test_is_email(validation):
    print("\n5. Testing is_email()")

    # True
    assert (validation.is_email("xyz@abc.def"))

    # False
    assert (not validation.is_email("xyzabcdef"))
    assert (not validation.is_email("xyz@@abcdef"))
    assert (not validation.is_email("@abcdef"))
    assert (not validation.is_email("xyz-ko@abcdef.com"))


if __name__ == '__main__':

    print("\nTesting ...")

    # Instantiate a validation object
    validation = Validation()

    test_is_numeric(validation)

    test_is_alphabetic(validation)

    test_is_alphanumeric(validation)

    test_is_phone_number(validation)

    test_is_email(validation)
