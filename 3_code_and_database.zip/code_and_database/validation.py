# Importing packages
# Importing regular expression
import re

# Validation class


class Validation():

    # This validation method checks if the data type netered is numeric or not
    # By using the in-built method called isnumeric()
    # if the output is numeric then the method will return true or else it returns false
    def is_numeric(self, val):
        val = str(val)  # only str have the isnumeric() method
        if val.isnumeric():
            print("Numeric")
            return True
        else:
            print("Not numeric")
            return False

    # This validation method checks if the data type entered is in alphabetic form or not
    # By using the in-built method called isalpha()
    # If the output is alphabetic then the method will return true or else it returns false

    def is_alphabetic(self, val):
        val = str(val)
        if val.isalpha():
            print("Alphabetic")
            return True
        else:
            print("Not alphabetic")
            return False

    def is_alphanumeric(self, val):
        val = str(val)
        if val.isalnum():
            print("Alphanumeric")
            return True
        else:
            print("Not alphanumeric")
            return False

    # This method checks for if the phone number entered is in correct format or not
    # It will check for if the phone number can match the example format commented below
    # 0414570776
    # 04 1457 0776
    # 61411543655
    # 61 411 543 655
    # +61411543655
    # +61 411 543 655

    def is_phone_number(self, val):
        val = str(val)
        if re.search(r'(^04[0-9]{8}$|^04 [0-9]{4} [0-9]{4}$|^61[0-9]{9}$|^61 [0-9]{3} [0-9]{3} [0-9]{3}$|^\+61[0-9]{9}$|^\+61 [0-9]{3} [0-9]{3} [0-9]{3}$)', val):  # 02 9999 9999
            print("Valid phone number")
            return True
        else:
            print("Invalid phone number")
            return False

    # This method checks for if the email entered is in correct format or not
    def is_email(self, val):
        val = str(val)

        if re.match(r'[\w_]+@{1}[\w.]+', val):
            print("Valid email")
            return True
        else:
            print("Invalid email")
            return False

    pass


# Main method
if __name__ == '__main__':
    pass
