# DAO for library_user table table

# Importing packages
import sqlite3

# Contants
# This constant will help this file to connect with the database tables created
DATABASE_URI = "EFL_library_system.db"


class UserDAO():

    def create(self, data):

        # Print statements for debugging
        print("\nCreating a user.....\n")
        print(f"data: {data}")

        # Creating empty place holder for storing result
        result = {}

        # First initilaise the connect to None
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Using Parameterized Query
            # i.e. question marks as placeholders for the actual values
            # 8 question marks as library_user has 8 attributes
            query = "INSERT INTO library_user VALUES (?, ?, ?, ?, ?, ?, ?, ?);"
            param_tuple = (
                None,
                data['staff_id'],
                data['title'],
                data['first_name'],
                data['last_name'],
                data['age'],
                data['phone'],
                data['email'])
            cur.execute(query, param_tuple)
            result['message'] = 'User added successfully.'

            # Get teh id of record that just got inseted by using the cursor, curr
            inserted_user_id = cur.lastrowid
            print(f"inserted_staff_id: {inserted_user_id}")
            result['user_id'] = inserted_user_id

            cur.close()
            conn.commit()

        except sqlite3.Error as error:
            # This part of the code is executed if an error occures
            # when executing any statement in the try block
            result['message'] = 'Failed to create user.'
            print(f"Database {DATABASE_URI} - Create user failed!")
            print(error)

        finally:
            # This code block is always executed - even if an exception occurs
            # Here the connection gets closed as well
            if conn:
                conn.close()

        return result

    def find_by_id(self, user_id):

        # Print statements for debugging
        print("\nFinding a user.....\n")
        print(f"user_id: {user_id}")

        # Creating empty place holder for storing result
        result = {}

        # First initilaise the connect to None
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Using Parameterized Query
            # i.e. question marks as placeholders for the actual values
            query = "SELECT * FROM library_user WHERE user_id = ?;"

            param_tuple = (user_id, )

            cur.execute(query, param_tuple)
            # Getting the next row as there would be only one row that would be returned by the databse
            row = cur.fetchone()
            if row:
                # description refers to the name of the columns
                # The column name is refering to the first record illustrated by '0'
                col_names = [description[0] for description in cur.description]

                # Using dictionary comprehension and enumerate() to match the column names with their index positions
                s = {key: row[i] for i, key in enumerate(col_names)}

                result['user'] = s
            else:
                result['message'] = "User not found"
            cur.close()
            conn.commit

        except sqlite3.Error as error:
            result['message'] = "Find by id failed"
            print(error)

        finally:
            # This code block is alwasy executed - even if an exception occurs
            # Here the connection gets closed as well
            if conn:
                conn.close()

        # Returning the result as dictionary
        return result

    def find_by_last_name(self, last_name):
        # Print statements for debugging
        print("\nFinding a user by their last name.....\n")
        print(f"last_name: {last_name}")

        # Creating empty place holder for storing result
        result = {}

        # First initilaise the connect to None
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Using Parameterized Query
            # i.e. question marks as placeholders for the actual values
            query = "SELECT * FROM library_user WHERE last_name = ?;"

            param_tuple = (last_name, )

            cur.execute(query, param_tuple)
            # Getting all the user record with same last name thus used fetchall() method
            rows = cur.fetchall()
            if rows:
                print(f"rows: {rows}")

                # Converting the list of row objects to a list of dictionaries
                # As we need more than one record of last names
                # This query is done so that it can return more than one user
                # Hence creating a list
                # Create an empty list to append user dicts
                list_users = []

                # rows is a list of SQlite objects - process one by one
                for x in rows:
                    # description refers to the name of the columns
                    # The column name is refering to the first record illustrated by '0'
                    col_names = [description[0]
                                 for description in cur.description]

                    # Using dictionary comprehension and enumerate() to match the column names with their index positions
                    s = {key: x[i] for i, key in enumerate(col_names)}

                    # Append the users dict to the user list
                    list_users.append(s)

                # Store the user list in the result dict under key "user"
                result['user'] = list_users

            else:
                result['message'] = "User not found"
            cur.close()
            conn.commit

        except sqlite3.Error as error:
            result['message'] = "Find by last name failed"
            print(error)

        finally:
            # This code block is alwasy executed - even if an exception occurs
            # Here the connection gets closed as well
            if conn:
                conn.close()

        # Returning the result as dictionary
        return result

    def find_all(self):

        # Print statements for debugging
        print("\nFinding all library users.....\n")

        # Creating empty place holder for storing result
        result = {}

        # First initilaise the connect to None
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Using Parameterized Query
            query = "SELECT * FROM library_user;"

            cur.execute(query)

            # Getting all the user record thus used fetchall() method
            rows = cur.fetchall()
            if rows:
                print(f"rows: {rows}")

                # Converting the list of row objects to a list of dictionaries
                # As we need more than one record of last names
                # This query is done so that it can return more than one user
                # Hence creating a list
                # Create an empty list to append user dicts
                list_users = []

                # rows is a list of SQlite objects - process one by one
                for x in rows:
                    # description refers to the name of the columns
                    # The column name is refering to the first record illustrated by '0'
                    col_names = [description[0]
                                 for description in cur.description]

                    # Using dictionary comprehension and enumerate() to match the column names with their index positions
                    s = {key: x[i] for i, key in enumerate(col_names)}

                    # Append the users dict to the user list
                    list_users.append(s)
                    pass

                # Store the user list in the result dict under key "user"
                result['users'] = list_users

            else:
                result['message'] = "No library user found"
            cur.close()
            conn.commit

        except sqlite3.Error as error:
            result['message'] = "Find all failed"
            print(error)

        finally:
            # This code block is always executed - even if an exception occurs
            # Here the connection gets closed as well
            if conn:
                conn.close()

        # Returning the result as dictionary
        return result

    def find_ids(self):
        # Print statements for debugging
        print("\nFinding all user members ids.....\n")

        # Creating empty place holder for storing result
        result = {}

        # First initilaise the connect to None
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Using Parameterized Query
            # i.e. question marks as placeholders for the actual values
            query = "SELECT user_id FROM library_user;"

            cur.execute(query)

            # Getting all the user record thus used fetchall() method
            rows = cur.fetchall()
            if rows:
                # List comprehension to grab first element of the tuple
                result['user_ids'] = [x[0] for x in rows]
            else:
                result['message'] = "No user members found"
            cur.close()
            conn.commit

        except sqlite3.Error as error:
            result['message'] = "Find ids failed"
            print(error)

        finally:
            # This code block is always executed - even if an exception occurs
            # Here the connection gets closed as well
            if conn:
                conn.close()

        # Returning the result as dictionary
        return result

    def update(self, user_id, data):

        # Print info for debugging
        print("\nUpdating user info ...\n")
        print(f"user_id: {user_id}")
        print(f"data: {data}")

        # Create a blank dictionary to return the result
        result = {}

        # Using Parameterised Query
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Update all the attributes in library_user table except user_id
            query = """UPDATE library_user
               SET 
                  staff_id=?,
                  title=?,
                  first_name=?, 
                  last_name=?, 
                  age=?,
                  phone=?,
                  email=?
               WHERE 
                  user_id = ?;"""
            param_tuple = (
                data['staff_id'],
                data['title'],
                data['first_name'],
                data['last_name'],
                data['age'],
                data['phone'],
                data['email'],
                user_id)
            cur.execute(query, param_tuple)
            result['message'] = 'User info Updated!'
            cur.close()
            conn.commit()
        except sqlite3.Error as error:
            result['message'] = 'User NOT updated!'
            print(f"Database {DATABASE_URI} - Update user failed")
            print(error)
        finally:
            if conn:
                conn.close()
                #print("Database closed")

        #print(f"result: {result}")
        return result

    def delete(self, user_id):

        # Print statements for debugging
        print("\nDeleting user ...\n")
        print(f"user_id: {user_id}")

        # Create a blank dictionary to return the result
        result = {}

        # Using Parameterised Query
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            query = "DELETE FROM library_user WHERE user_id = ?;"
            param_tuple = (user_id, )
            cur.execute(query, param_tuple)
            result['message'] = 'User deleted!'
            cur.close()
            conn.commit()
        except sqlite3.Error as error:
            result['message'] = 'User NOT deleted!'
            print(f"Database {DATABASE_URI} - Delete user failed")
            print(error)
        finally:
            if conn:
                conn.close()
                #print("Database closed")

        return result  # return the result as a dictionary
