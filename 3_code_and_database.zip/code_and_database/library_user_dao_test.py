# Test file for testing library_user_dao

# Importing the DAO
# From library_user_dao.py file importing the class UserDAO()
from library_user_dao import UserDAO


# Testing the create method of UserDAO class
def test_create():

    # Printing information for debugging
    print("\n1. Test create a library user ....")

    # Instantiating the user DAO
    user_dao = UserDAO()

    # Setting up the data in JSON format
    data = {
        'staff_id': '1',
        'title': "Ms",
        'first_name': "Nusha",
        'last_name': "Rahman",
        'age': "20",
        'phone': "+61 412 567 644",
        'email': "nusha@gmail.com"
    }

    # Call the create() method from DAO
    # and pass the dictionary as parameter
    result = user_dao.create(data)

    # Printing the result
    print(result)


# Testing the find_by_id method of UserDAO class
def test_find_by_id():

    # Print info for debugging
    print("\n2. Test find by id ...")

    # Instantiate the user DAO
    user_dao = UserDAO()

    # Assigning a staff_id
    user_id = 1    # This will show that the user is found
    # staff_id = 5    # Running this will show that the user is not found

    result = user_dao.find_by_id(user_id)

    # Printing result
    print(result)


def test_find_all():

    # Print info for debugging
    print("\n3. Test find all ...")

    # Instantiate the user DAO
    user_dao = UserDAO()

    result = user_dao.find_all()

    # Print the result
    print(result)


def find_by_last_name():

    # Print info for debugging
    print("\n4. Test find by lastname  ...")

    # Instantiate the user DAO
    user_dao = UserDAO()

    # Assign a lastname
    last_name = "Rahman"         # If run will exist
    # last_name = "Mate"           # If run eill not exist

    result = user_dao.find_by_last_name(last_name)

    # Print the result
    print(result)


def test_find_ids():

    # Print info for debugging
    print("\n5. Test find ids ...")

    # Instantiate the user DAO
    user_dao = UserDAO()

    # Call the find_ids() method from the DAO
    result = user_dao.find_ids()

    # Print the result
    print(result)


def test_update():

    # Print info for debugging
    print("\n6. Test update staff info ...")

    # Instantiate the user DAO
    user_dao = UserDAO()

    # Assign an user_id
    user_id = 1  # exists
    # user_id = 2 # does not exist?

    # Create a dictionary and add items
    # Do not add the user_id to the dict
    data = {}
    data['title'] = "Ms"
    data['first_name'] = "Sara"
    data['last_name'] = "Ali"
    data['phone'] = "+61 412 345 322"
    data['email'] = "sara@gmail.com"

    # Call the update() method from the DAO
    # and pass the user_id and data as parameters
    result = user_dao.update(user_id, data)

    # Print the result
    print(result)


def test_delete():

    # Print info for debugging
    print("\n7. Test delete a staff ...")

    user_dao = UserDAO()

    # Assign an user_id
    user_id = 1  # exists
    # user_id = 2 # does not exist?

    # Call the delete() method from the DAO
    # and pass the user_id as parameter
    result = user_dao.delete(user_id)

    # Print the result
    print(result)


if __name__ == "__main__":

    print("\nTesting User DAO ...")
    print("Please ensure that you perform the tests on a blank database ...")

    print()
    input("Press Enter to continue or Ctrl+C to cancel ...")

    # 1. Test create method from doctor_dao.py
    test_create()

    # 2. Test find by id method from doctor_dao.py
    test_find_by_id()

    # 3. Test find all method from doctor_dao.py
    test_find_all()

    # 4. Test find by lastname method from doctor_dao.py
    find_by_last_name()

    # 5. Test find ids method from doctor_dao.py
    test_find_ids()

    # 6. Test update method from doctor_dao.py
    test_update()

    # 7. Test delete method from doctor_dao.py
    test_delete()

    print("\nAll done!")

    print("\nPlease use DB Browser for SQLite to check the database!")
