# DAO for staff table

# Importing packages
import sqlite3

# Contants
# This constant will help this file to connect with the database tables created
DATABASE_URI = "EFL_library_system.db"


class StaffDAO():

    def create(self, data):

        # Print statements for debugging
        print("\nCreating a staff.....\n")
        print(f"data: {data}")

        # Creating empty place holder for storing result
        result = {}

        # First initilaise the connect to None
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Using Parameterized Query
            # i.e. question marks as placeholders for the actual values
            # 6 question marks as staff has 6 attributes
            query = "INSERT INTO staff VALUES (?, ?, ?, ?, ?, ?);"
            param_tuple = (
                None,       # staff_id is set to Non as it will be auto incremented
                data['title'],
                data['first_name'],
                data['last_name'],
                data['phone'],
                data['email'])
            cur.execute(query, param_tuple)
            result['message'] = 'Staff added successfully.'

            # Get teh id of record that just got inseted by using the cursor, curr
            inserted_staff_id = cur.lastrowid
            print(f"inserted_staff_id: {inserted_staff_id}")
            result['staff_id'] = inserted_staff_id

            cur.close()
            conn.commit()

        except sqlite3.Error as error:
            # This part of the code is executed if an error occures
            # when executing any statement in the try block
            result['message'] = 'Failed to create staff.'
            print(f"Database {DATABASE_URI} - Create staff failed!")
            print(error)

        finally:
            # This code block is always executed - even if an exception occurs
            # Here the connection gets closed as well
            if conn:
                conn.close()

        return result

    def find_by_id(self, staff_id):

        # Print statements for debugging
        print("\nFinding a staff.....\n")
        print(f"staff_id: {staff_id}")

        # Creating empty place holder for storing result
        result = {}

        # First initilaise the connect to None
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Using Parameterized Query
            # i.e. question marks as placeholders for the actual values
            query = "SELECT * FROM staff WHERE staff_id = ?;"

            param_tuple = (staff_id, )

            cur.execute(query, param_tuple)
            # Getting the next row as there would be only one row that would be returned by the databse
            row = cur.fetchone()
            if row:
                # description refers to the name of the columns
                # The column name is refering to the first record illustrated by '0'
                col_names = [description[0] for description in cur.description]

                # Using dictionary comprehension and enumerate() to match the column names with their index positions
                s = {key: row[i] for i, key in enumerate(col_names)}

                result['staff'] = s
            else:
                result['message'] = "Staff not found"
            cur.close()
            conn.commit

        except sqlite3.Error as error:
            result['message'] = "Find by id failed"
            print(error)

        finally:
            # This code block is alwasy executed - even if an exception occurs
            # Here the connection gets closed as well
            if conn:
                conn.close()

        # Returning the result as dictionary
        return result

    def find_by_last_name(self, last_name):
        # Print statements for debugging
        print("\nFinding a staff by their last name.....\n")
        print(f"last_name: {last_name}")

        # Creating empty place holder for storing result
        result = {}

        # First initilaise the connect to None
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Using Parameterized Query
            # i.e. question marks as placeholders for the actual values
            query = "SELECT * FROM staff WHERE last_name = ?;"

            param_tuple = (last_name, )

            cur.execute(query, param_tuple)
            # Getting all the staff record with same last name thus used fetchall() method
            rows = cur.fetchall()
            if rows:
                print(f"rows: {rows}")

                # Converting the list of row objects to a list of dictionaries
                # As we need more than one record of last names
                # This query is done so that it can return more than one staff
                # Hence creating a list
                # Create an empty list to append staff dicts
                list_staffs = []

                # rows is a list of SQlite objects - process one by one
                for x in rows:
                    # description refers to the name of the columns
                    # The column name is refering to the first record illustrated by '0'
                    col_names = [description[0]
                                 for description in cur.description]

                    # Using dictionary comprehension and enumerate() to match the column names with their index positions
                    s = {key: x[i] for i, key in enumerate(col_names)}

                    # Append the staff dict to the staff list
                    list_staffs.append(s)

                # Store the staff list in the result dict under key "staff"
                result['staff'] = list_staffs

            else:
                result['message'] = "Staff not found"
            cur.close()
            conn.commit

        except sqlite3.Error as error:
            result['message'] = "Find by last name failed"
            print(error)

        finally:
            # This code block is alwasy executed - even if an exception occurs
            # Here the connection gets closed as well
            if conn:
                conn.close()

        # Returning the result as dictionary
        return result

    def find_all(self):

        # Print statements for debugging
        print("\nFinding all staff members.....\n")

        # Creating empty place holder for storing result
        result = {}

        # First initilaise the connect to None
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Using Parameterized Query
            # i.e. question marks as placeholders for the actual values
            query = "SELECT * FROM staff;"

            cur.execute(query)

            # Getting all the staff record thus used fetchall() method
            rows = cur.fetchall()
            if rows:
                print(f"rows: {rows}")

                # Converting the list of row objects to a list of dictionaries
                # As we need more than one record of last names
                # This query is done so that it can return more than one staff
                # Hence creating a list
                # Create an empty list to append staff dicts
                list_staffs = []

                # rows is a list of SQlite objects - process one by one
                for x in rows:
                    # description refers to the name of the columns
                    # The column name is refering to the first record illustrated by '0'
                    col_names = [description[0]
                                 for description in cur.description]

                    # Using dictionary comprehension and enumerate() to match the column names with their index positions
                    s = {key: x[i] for i, key in enumerate(col_names)}

                    # Append the doctor dict to the doctor list
                    list_staffs.append(s)
                    pass

                # Store the staff list in the result dict under key "staff"
                result['staff'] = list_staffs

            else:
                result['message'] = "No staff members found"
            cur.close()
            conn.commit

        except sqlite3.Error as error:
            result['message'] = "Find all failed"
            print(error)

        finally:
            # This code block is always executed - even if an exception occurs
            # Here the connection gets closed as well
            if conn:
                conn.close()

        # Returning the result as dictionary
        return result

    def find_ids(self):
        # Print statements for debugging
        print("\nFinding all staff members ids.....\n")

        # Creating empty place holder for storing result
        result = {}

        # First initilaise the connect to None
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Using Parameterized Query
            # i.e. question marks as placeholders for the actual values
            query = "SELECT staff_id FROM staff;"

            cur.execute(query)

            # Getting all the staff record thus used fetchall() method
            rows = cur.fetchall()
            if rows:
                # List comprehension to grab first element of the tuple
                result['staff_ids'] = [x[0] for x in rows]
            else:
                result['message'] = "No staff members found"
            cur.close()
            conn.commit

        except sqlite3.Error as error:
            result['message'] = "Find ids failed"
            print(error)

        finally:
            # This code block is always executed - even if an exception occurs
            # Here the connection gets closed as well
            if conn:
                conn.close()

        # Returning the result as dictionary
        return result

    def update(self, staff_id, data):

        # Print info for debugging
        print("\nUpdating staff info ...\n")
        print(f"staff_id: {staff_id}")
        print(f"data: {data}")

        # Create a blank dictionary to return the result
        result = {}

        # Using Parameterised Query
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            # Update all the attributes in staff table except staff_id
            query = """UPDATE staff
               SET 
                  title=?,
                  first_name=?, 
                  last_name=?, 
                  phone=?,
                  email=?
               WHERE 
                  staff_id = ?;"""
            param_tuple = (
                data['title'],
                data['first_name'],
                data['last_name'],
                data['phone'],
                data['email'],
                staff_id)
            cur.execute(query, param_tuple)
            result['message'] = 'Staff info Updated!'
            cur.close()
            conn.commit()
        except sqlite3.Error as error:
            result['message'] = 'Staff NOT updated!'
            print(f"Database {DATABASE_URI} - Update staff failed")
            print(error)
        finally:
            if conn:
                conn.close()
                #print("Database closed")

        #print(f"result: {result}")
        return result

    def delete(self, staff_id):

        # Print statements for debugging
        print("\nDeleting staff ...\n")
        print(f"staff_id: {staff_id}")

        # Create a blank dictionary to return the result
        result = {}

        # Using Parameterised Query
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_URI)
            cur = conn.cursor()
            query = "DELETE FROM staff WHERE staff_id = ?;"
            param_tuple = (staff_id, )
            cur.execute(query, param_tuple)
            result['message'] = 'staff deleted!'
            cur.close()
            conn.commit()
        except sqlite3.Error as error:
            result['message'] = 'Staff NOT deleted!'
            print(f"Database {DATABASE_URI} - Delete staff failed")
            print(error)
        finally:
            if conn:
                conn.close()
                #print("Database closed")

        return result  # return the result as a dictionary
